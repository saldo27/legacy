class SchedulerError(Exception):
    """Custom exception for Scheduler errors"""
    pass
